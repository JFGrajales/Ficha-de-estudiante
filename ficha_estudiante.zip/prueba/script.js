const datos = document.querySelector("#cargar");
function cargarinfo() {
    let i = 0;
    let cont = ""; 
  fetch("Estudiante.json")
    .then((res) => res.json())
    .then((estudiante) => {
      var Estudiantes = Object.values(estudiante.Estudiante);
      for (i = 0; i < Estudiantes.length; i++) {
        console.log(Estudiantes);
        var titulo =`<header><h1 class="title">FICHA DE ESTUDIANTE</h1></header>`;
        var foto = `<div class="ficha">
        <img class="imagen" src="${Estudiantes[i].foto}">`;
        var nombre = `<div class="divNombre" > <h1 class="nombre">${Estudiantes[i].nombre}</h1></div> `;
        var carrera = `<div class="divCarrera" > <h2 class="carrera">${Estudiantes[i].carrera}</h2></div>`;

        var neocities = `<div class="divNeocities">
        <a href="${Estudiantes[i].neocities}"target=_blank"><img class="correo" src="/retos/prueba/images/neo.png"></a>`;
        var github = `
        <a href="${Estudiantes[i].github}" target="_blank"><img class="correo" src="/retos/prueba/images/Github.png"></a>`;
        
        var uni = `<div class="divU">
        <h2 class="universidad">${Estudiantes[i].universidad}</h2></div></div>`;
        cont = titulo + foto + nombre + carrera + neocities + github+ uni;
      }
      datos.innerHTML = cont;
    });
}
cargarinfo();